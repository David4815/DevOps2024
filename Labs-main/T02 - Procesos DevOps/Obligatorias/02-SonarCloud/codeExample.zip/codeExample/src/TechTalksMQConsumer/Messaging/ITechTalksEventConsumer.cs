namespace TechTalksProcessor.Messaging
{
    public interface ITechTalksEventConsumer 
    {
        void ConsumeMessage();
    }
}