namespace TechTalksAPI.Model
{
    public class Level
    {
        public int Id { get; set; }
        public string LevelName { get; set; }
    }
}