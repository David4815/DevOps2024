// Polyfills index

// IE 10
// import 'core-js/es6/map';
// import 'core-js/es6/set';

// IE 9
// import 'raf/polyfill';
// import 'classlist.js';

export {};
